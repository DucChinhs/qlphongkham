package control;

import general.user;

public class finalClass {
    public static final String headerFile = "C:\\Users\\tuanp\\Desktop\\qlbenhnhan\\demo\\src\\Data\\";
    public static user currentUser;
}
